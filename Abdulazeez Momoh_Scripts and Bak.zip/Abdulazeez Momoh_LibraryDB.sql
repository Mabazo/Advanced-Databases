--First, create a new database called "LibraryDB"
CREATE DATABASE LibraryDB;

--Switch to the newly created database:
USE LibraryDB;
GO

--QUESTION 1. Database design and Normalization--
--Assumptions--
--a. Overdue fines are calculated on a daily basis and don't depend on the item type.
--b. Overdue fine repayments can be partial or in full, but the payment should not exceed the outstanding balance.
--c. The library doesn't require information on the staff responsible for processing loans or repayments.

---To design the database in 3NF, we will create the following tables:


--a. Addresses
--AddressID (int, PK, identity, not null): It is set as NOT NULL and as the PRIMARY KEY, ensuring that each row has a unique, non-null identifier.
--Address1(nvarchar(50) not null): It  is set as NOT NULL. It will store the first line of the address.
--Address2(nvarchar(50) null): It is set as NULL, allowing for optional storage of a second line of the address.
--City (nvarchar(50) null): It is set as NULL, which means that storing the city is optional.
--PostCode (nvarchar(10)): It is set as NOT NULL, It will store the postal code for the address.
--CONSTRAINT UC_Address UNIQUE (Address1, Postcode) This is a UNIQUE constraint applied to the combination of the Address1 and Postcode columns. 

--b. Members
--MemberID (int, PK, identity): Unique identifier for each member.
--FirstName (nvarchar(50)): First name of the member.
--LastName (nvarchar(50)): Last name of the member
--DateOfBirth (date): Member's date of birth.
--Username (nvarchar(50), unique): Member's chosen username.
--Password (nvarchar(255)): Member's password (should be hashed and salted).
--Email (nvarchar(255), null): Member's email address (optional).
--PhoneNumber (nvarchar(20), null): Member's phone number (optional).
--MembershipEndDate (date, null): Date when the membership ended (optional).
--AddressID: Non-nullable foreign key column referencing the Addresses table's AddressID column.


--c. Items
--ItemID (int, PK, identity): Unique identifier for each item.
--Title (nvarchar(255)): Title of the item.
--ItemType (nvarchar(50)): Book, Journal, DVD, or Other Media.
--Author (nvarchar(255)): Author of the item.
--YearOfPublication (int): Year the item was published.
--DateAdded (date): Date the item was added to the collection.
--CurrentStatus (nvarchar(50)): On Loan, Overdue, Available, or Lost/Removed.
--StatusDate (date, null): Date the item was marked as Lost/Removed (optional).
--ISBN (nvarchar(13), null): ISBN for books (optional).

--c. Loans
--LoanID (int, PK, identity): Unique identifier for each loan.
--MemberID (int, FK): References Members table.
--ItemID (int, FK): References Items table.
--DateTakenOut (datetime): Date the item was borrowed.
--DateDueBack (datetime): Date the item is due to be returned.
--DateReturned (datetime, null): Date the item was returned (optional).\

--d. OverdueFines
--FineID (int, PK, identity): Unique identifier for each overdue fine.
--MemberID (int, FK): References Members table.
--LoanID (int, FK): References Loans table.
--AmountDue (decimal(10,2)): Amount owed for the overdue item.

--e. FineRepayments
--RepaymentID (int, PK, identity): Unique identifier for each repayment.
--FineID (int, FK): References OverdueFines table.
--RepaymentDate (datetime): Date and time of the repayment.
--AmountRepaid (decimal(10,2)): Amount repaid by the member.
--RepaymentMethod (nvarchar(50)): Cash or Card.


--After designing the database in 3NF, we proceed to create tables
--Table creation

--a. Creating the Addresses Table
CREATE TABLE Addresses (
AddressID INT IDENTITY NOT NULL PRIMARY KEY,
Address1 NVARCHAR(50) NOT NULL,
Address2 NVARCHAR(50) NULL,
City NVARCHAR(50) NULL,
Postcode NVARCHAR(10) NOT NULL,
CONSTRAINT UC_Address UNIQUE (Address1, Postcode)
);

--b. Creating the Members Table
CREATE TABLE Members (
    MemberID INT NOT NULL PRIMARY KEY IDENTITY,
    FirstName NVARCHAR(50) NOT NULL,
    LastName NVARCHAR(50) NOT NULL,
	DateOfBirth DATE NOT NULL,
    Username NVARCHAR(50) NOT NULL UNIQUE,
    Password NVARCHAR(255) NOT NULL,
    Email NVARCHAR(255) NULL,
    PhoneNumber NVARCHAR(20) NULL,
    MembershipEndDate DATE NULL,
	AddressID INT NOT NULL FOREIGN KEY REFERENCES Addresses(AddressID)
);

--c. Creating the Items Table
CREATE TABLE Items (
    ItemID INT NOT NULL PRIMARY KEY IDENTITY,
    Title NVARCHAR(255) NOT NULL,
    ItemType NVARCHAR(50) NOT NULL CHECK (ItemType IN ('Book', 'Journal', 'DVD', 'Other Media')),
    Author NVARCHAR(255) NOT NULL,
    YearOfPublication INT NOT NULL,
    DateAdded DATE NOT NULL,
    CurrentStatus NVARCHAR(50) NOT NULL CHECK (CurrentStatus IN ('On Loan', 'Overdue', 'Available', 'Lost/Removed')),
    StatusDate DATE NULL,
    ISBN NVARCHAR(20) NULL
);

--d. Creating the Loans Table
CREATE TABLE Loans (
    LoanID INT NOT NULL PRIMARY KEY IDENTITY,
    MemberID INT NOT NULL FOREIGN KEY REFERENCES Members(MemberID),
    ItemID INT NOT NULL FOREIGN KEY REFERENCES Items(ItemID),
    DateTakenOut DATETIME NOT NULL,
    DateDueBack DATETIME NOT NULL,
    DateReturned DATETIME NULL
);

--e. Creating the OverdueFines Table
CREATE TABLE OverdueFines (
    FineID INT NOT NULL PRIMARY KEY IDENTITY,
    MemberID INT NOT NULL FOREIGN KEY REFERENCES Members(MemberID),
    LoanID INT NOT NULL FOREIGN KEY REFERENCES Loans(LoanID),
    AmountDue DECIMAL(10, 2) NOT NULL
);

--f. Creating the FineRepayments Table
CREATE TABLE FineRepayments (
    RepaymentID INT NOT NULL PRIMARY KEY IDENTITY,
    FineID INT NOT NULL FOREIGN KEY REFERENCES OverdueFines(FineID),
    RepaymentDate DATETIME NOT NULL,
    AmountRepaid DECIMAL(10, 2) NOT NULL,
    RepaymentMethod NVARCHAR(50) NOT NULL CHECK (RepaymentMethod IN ('Cash', 'Card'))
);
GO

--QUESTION 2. Creating stored procedures and user- defined functions for specific requirements. 

--These stored procedures and user-defined functions will provide the functionality required by the library. To use them, simply replace the placeholder values with the appropriate data in the usage examples provided.

--a) Search the catalogue for matching strings by title
CREATE PROCEDURE SearchCatalogueByTitle
    @SearchString NVARCHAR(255)
AS
BEGIN
    SELECT *
    FROM Items
    WHERE Title LIKE '%' + @SearchString + '%'
    ORDER BY YearOfPublication DESC;
END;
GO
--Usage
EXEC SearchCatalogueByTitle @SearchString = '@SearchItem';
GO

--b) Return a full list of all items currently on loan with a due date less than five days from the current date.
CREATE FUNCTION ItemsDueWithinFiveDays()
RETURNS TABLE
AS
RETURN (
    SELECT *
    FROM Loans
    WHERE DateDueBack BETWEEN GETDATE() AND DATEADD(DAY, 5, GETDATE())
    AND DateReturned IS NULL
);
GO

--Usage
SELECT * FROM ItemsDueWithinFiveDays();
GO

--c) Inserting a new member into a database
CREATE PROCEDURE AddNewMember
    @FirstName NVARCHAR(50),
    @LastName NVARCHAR(50),
    @DateOfBirth DATE,
    @Username NVARCHAR(50),
    @Password NVARCHAR(255),
    @AddressID INT,
    @Email NVARCHAR(255) = NULL,
    @PhoneNumber NVARCHAR(20) = NULL
AS
BEGIN
    INSERT INTO Members (FirstName, LastName, DateOfBirth, Username, Password, AddressID, Email, PhoneNumber)
    VALUES (@FirstName, @LastName, @DateOfBirth, @Username, @Password, @AddressID, @Email, @PhoneNumber);
END;

--Usage
---- Insert a new member with their details

--EXEC AddNewMember
--@FirstName = 'Marcus',
 --@LastName = 'Rashford',
 --@DateOfBirth = '1995-06-15',
 --@Username = 'marcusrashford',
 --@Password = 'M0rcD03P@ss',
 --@AddressID = 1, -- Assuming an existing AddressID
 --@Email = 'marcus.rashford@mail.com',
 --@PhoneNumber = '555-123-4567';

GO

--d) Update the details for an existing member

CREATE PROCEDURE UpdateMemberDetails
    @MemberID INT,
    @FirstName NVARCHAR(50) = NULL,
    @LastName NVARCHAR(50) = NULL,
    @DateOfBirth DATE = NULL,
    @Username NVARCHAR(50) = NULL,
    @Password NVARCHAR(255) = NULL,
    @AddressID INT = NULL,
    @Email NVARCHAR(255) = NULL,
    @PhoneNumber NVARCHAR(20) = NULL
AS
BEGIN
    UPDATE Members
    SET FirstName = COALESCE(@FirstName, FirstName),
        LastName = COALESCE(@LastName, LastName),
        DateOfBirth = COALESCE(@DateOfBirth, DateOfBirth),
        Username = COALESCE(@Username, Username),
        Password = COALESCE(@Password, Password),
        AddressID = COALESCE(@AddressID, AddressID),
        Email = COALESCE(@Email, Email),
        PhoneNumber = COALESCE(@PhoneNumber, PhoneNumber)
    WHERE MemberID = @MemberID;
END;

--Usage

--Update an existing member's email and phone number (MemberID = 1)
EXEC UpdateMemberDetails
@MemberID = 1,
@Email = 'marcus.rashford.updated@mail.com',
@PhoneNumber = '555-123-4567';

GO

--QUESTION 3. To create a view that shows the loan history, including details of the item borrowed, borrowed date, due date, and any associated fines for each loan
CREATE VIEW LoanHistory AS
SELECT
    L.LoanID,
    M.FirstName + ' ' + M.LastName AS MemberName,
    M.MemberID,
    I.ItemID,
    I.Title,
    L.DateTakenOut,
    L.DateDueBack,
    L.DateReturned,
    CASE
        WHEN L.DateReturned IS NULL AND DATEDIFF(DAY, L.DateDueBack, GETDATE()) > 0 THEN DATEDIFF(DAY, L.DateDueBack, GETDATE()) * 0.10
        WHEN L.DateReturned IS NOT NULL AND DATEDIFF(DAY, L.DateDueBack, L.DateReturned) > 0 THEN DATEDIFF(DAY, L.DateDueBack, L.DateReturned) * 0.10
        ELSE 0
    END AS FineAmount
FROM
    Loans L
    INNER JOIN Members M ON L.MemberID = M.MemberID
    INNER JOIN Items I ON L.ItemID = I.ItemID;

	GO
-- This view shows the loan history with all previous and current loans, including details of the item borrowed, borrowed date, due date, and any associated overdue fees. Overdue fees are calculated at a rate of 10p per day for overdue items.

-- To query the view
SELECT * FROM LoanHistory;
GO

-- The above code will return a result set with the loan history, including all previous and current loans, as well as details about the items borrowed, borrowed dates, due dates, and any associated fines.

--QUESTION 4
--To create a trigger that automatically updates the current status of an item to 'Available' when the book is returned

CREATE TRIGGER UpdateItemStatusOnReturn
ON Loans
AFTER UPDATE
AS
BEGIN
    IF UPDATE(DateReturned)
    BEGIN
        DECLARE @ItemID INT;
        SELECT @ItemID = ItemID FROM inserted;

        UPDATE Items
        SET CurrentStatus = 'Available'
        WHERE ItemID = @ItemID;
    END;
END;

GO

--This trigger, named UpdateItemStatusOnReturn, is set to execute after an update on the Loans table. It checks if the DateReturned column has been updated and, if so, retrieves the ItemID from the inserted table. The trigger then updates the CurrentStatus of the item in the Items table to 'Available'.
--After creating this trigger, when you update the DateReturned column in the Loans table, the item's status will be automatically updated to 'Available':

--UPDATE Loans
--SET DateReturned = GETDATE()
--WHERE LoanID = <YourLoanID>;
--Replace <YourLoanID> with the actual loan ID for which you want to update the DateReturned column.

--QUESTION 5
--To create a function that returns the total number of loans made on a specified date

CREATE FUNCTION GetTotalLoansByDate(@LoanDate DATE)
RETURNS INT
AS
BEGIN
    DECLARE @TotalLoans INT;

    SELECT @TotalLoans = COUNT(*)
    FROM Loans
    WHERE CAST(DateTakenOut AS DATE) = @LoanDate;

    RETURN @TotalLoans;
END;
GO

--This function, named GetTotalLoansByDate, takes a @LoanDate parameter as input and calculates the total number of loans made on that date. To use this function, you can execute the following query:
--SELECT dbo.GetTotalLoansByDate('YYYY-MM-DD') AS TotalLoans;
--By replacing  'YYYY-MM-DD' with the actual date for which you want to get the total number of loans. The result will show the total loans made on the specified date.

--QUESTION 6
--Inserting some records into each of the table

--a) Inserting records into Addresses Table
INSERT INTO Addresses (Address1, Address2, City, Postcode)
VALUES ('123 Main St', NULL, 'Lagos', '100001'),
       ('52 High Road', 'Apt 4B', 'Cape Town', '8001'),
       ('789 Elm St', NULL, 'Nairobi', '00100'),
       ('5th Avenue', 'Suite 22', 'Accra', 'GA-12345'),
       ('20 Market St', NULL, 'Johannesburg', '2000');


--b) Inserting records into Members Table
INSERT INTO Members (FirstName, LastName, DateOfBirth, Username, Password, Email, PhoneNumber, MembershipEndDate, AddressID)
VALUES ('Ade', 'Ola', '1990-01-01', 'adeola', 'secure123', 'adeola@example.com', '+2348023456789', '2023-12-31', 1),
       ('Thandi', 'Nkosi', '1985-04-15', 'tnkosi', 'password123', 'tnkosi@example.com', '+272112345678', '2024-01-31',  2),
       ('John', 'Kamau', '1978-08-21', 'jkamau', 'mypassword', 'john.kamau@example.com', '+254700123456', '2025-01-31', 3),
       ('Kwame', 'Asante', '2000-12-30', 'kasante', 'ghana2000', 'kwame.asante@example.com', '+233201234567', '2026-01-31', 4),
       ('Sipho', 'Dlamini', '1995-07-08', 'sdlamini', 'southafrica95', 'sipho.dlamini@example.com', '+27123456789', '2024-01-31', 5);


--c) Inserting records into items table
INSERT INTO Items (Title, Author, YearOfPublication, DateAdded, ItemType, CurrentStatus, StatusDate, ISBN)
VALUES ('African Legends', 'Amaka Okoli', '2019', '2019-05-15', 'Book', 'Available', '2019-05-25', '978-1-23456-789-0'),
       ('The Great Migration', 'Tendai Mutasa', '2021', '2021-03-12', 'Book', 'Available', '2021-03-22', '978-1-23456-789-1'),
       ('Innovators of Africa', 'Daniel Mwangi', '2018', '2018-11-30', 'Book', 'Available', '2018-12-12',  '978-1-23456-789-2'),
       ('The Art of Ubuntu', 'Lerato Mokoena', '2020', '2020-07-20', 'Book', 'Available', '2020-07-27', '978-1-23456-789-3'),
       ('Discovering West Africa', 'Kofi Nkrumah', '2022', '2022-01-15', 'Book', 'Available', '2022-01-22', '978-1-23456-789-4');


--d) Inserting records into the Loans table
INSERT INTO Loans (MemberID, ItemID, DateTakenOut, DateDueBack, DateReturned)
VALUES (2, 2, '2023-02-01', '2023-02-15', '2023-02-10'),
       (3, 3, '2023-02-05', '2023-04-14', NULL),
       (4, 4, '2023-02-10', '2023-02-24', '2023-02-20'),
       (5, 5, '2023-02-15', '2023-03-01', NULL),
       (6, 6, '2023-02-20', '2023-03-06', '2023-03-01');


--e) Inserting records into OverdueFines table
INSERT INTO OverdueFines (MemberID, LoanID, AmountDue)
VALUES (2, 3, 2.50),
				(3, 4, 2.60),
				(4, 5, 2.70),
				(5, 6, 1.50),
				(6, 7, 3.50);

--f) Inserting records into FineRepayments table:
INSERT INTO FineRepayments (FineID, RepaymentDate, AmountRepaid, RepaymentMethod)
VALUES (5, '2023-03-16', 1.00, 'Cash'),
				(6, '2024-03-16', 1.40, 'Cash'),
				(7, '2026-03-16', 1.88, 'Card'),
				(8, '2026-03-16', 2.00, 'Card'),
				(9, '2027-03-16', 2.45, 'Cash');


-- Now that we have have inserted these records, we can test the SELECT queries, user-defined functions, stored procedures, and triggers by executing the following commands:

--1. Search the catalogue for matching character strings by title:
EXEC SearchCatalogueByTitle @SearchString = 'Great';

--2. Return a full list of all items currently on loan with a due date less than five days from the current date:
SELECT * FROM ItemsDueWithinFiveDays();

--3. Insert a new member into the database:

EXEC AddNewMember
@FirstName = 'Marcus',
 @LastName = 'Rashford',
 @DateOfBirth = '1995-06-15',
 @Username = 'marcusrashford',
 @Password = 'M0rcD03P@ss',
 @AddressID = 1, -- Assuming an existing AddressID
 @Email = 'marcus.rashford@mail.com',
 @PhoneNumber = '555-123-4567';

--4. Updating details for an existing member:
EXEC UpdateMemberDetails
@MemberID = 1,
@FirstName = 'Marcus',
@LastName = 'Rashford',
@AddressID = 1,
@DateOfBirth = '1995-06-15',
@Username = 'marcusrashford',
@Password = 'M0rcD03P@ss',
@Email = 'marcus.rashford@mail.com',
@PhoneNumber = '555-123-4567';

--5. Quering the LoanHistory view:
SELECT * FROM LoanHistory;

--6. Using the GetTotalLoansByDate function:
SELECT dbo.GetTotalLoansByDate('2023-02-15') AS TotalLoans;

--7. Updating a loan's DateReturned column and test the trigger that updates the item's status
UPDATE Loans
SET DateReturned = GETDATE()
WHERE LoanID = 2;
SELECT * FROM Items WHERE ItemID = 5;
GO

--QUESTION 7
--Additional database objects relevant to the library

--1.  View: MembersWithOverdueitems
--This view lists members with overdue items, along with the item details and the number of days overdue.

CREATE VIEW MembersWithOverdueItems
AS
SELECT M.MemberID, M.FirstName + ' ' + M.LastName AS MemberName, I.ItemID, I.Title, L.DateDueBack, DATEDIFF(DAY, L.DateDueBack, GETDATE()) AS DaysOverdue
FROM Members M
JOIN Loans L ON M.MemberID = L.MemberID
JOIN Items I ON L.ItemID = I.ItemID
WHERE L.DateReturned IS NULL AND L.DateDueBack < GETDATE();
GO
--To query this view:
SELECT * FROM MembersWithOverdueItems;
GO

--2. Stored Procedure: MostLoanedItems
--This stored procedure retrives the top N most loaned items in the library
CREATE PROCEDURE MostLoanedItems @TopN INT
AS
BEGIN
  SELECT TOP(@TopN) I.ItemID, I.Title, COUNT(L.LoanID) AS LoanCount
  FROM Items I
  JOIN Loans L ON I.ItemID = L.ItemID
  GROUP BY I.ItemID, I.Title
  ORDER BY LoanCount DESC;
END;

--To execute the stored procedure
EXEC MostLoanedItems @TopN = 5;

GO
--3. View: MemberLoanSummary
--This view provides a summary of each member's loan activity, including the total loans, current loans, and overdue loans.
CREATE VIEW MemberLoanSummary
AS
SELECT M.MemberID, M.FirstName + ' ' + M.LastName AS MemberName,
  (SELECT COUNT(*) FROM Loans WHERE MemberID = M.MemberID) AS TotalLoans,
  (SELECT COUNT(*) FROM Loans WHERE MemberID = M.MemberID AND DateReturned IS NULL) AS CurrentLoans,
  (SELECT COUNT(*) FROM Loans WHERE MemberID = M.MemberID AND DateReturned IS NULL AND DateDueBack < GETDATE()) AS OverdueLoans
FROM Members M;
GO
--To query this view:
SELECT * FROM MemberLoanSummary;
GO
--4. User-Defined Function: GetLoanCountForMember
--This user-defined function returns the total number of loans for a specific member.
CREATE FUNCTION GetLoanCountForMember(@MemberID INT)
RETURNS INT
AS
BEGIN
  DECLARE @LoanCount INT;

  SELECT @LoanCount = COUNT(*)
  FROM Loans
  WHERE MemberID = @MemberID;

  RETURN @LoanCount;
END;
GO
--To use the function in a select query
SELECT MemberID, FirstName + ' ' + LastName AS MemberName, dbo.GetLoanCountForMember(MemberID) AS LoanCount
FROM Members;
GO

--5. Reservations Table
--A table to manage item reservations by members. When an item is not available for loan, members can reserve it, and when the item becomes available, the member is notified.
CREATE TABLE Reservations (
    ReservationID INT PRIMARY KEY IDENTITY,
    MemberID INT NOT NULL FOREIGN KEY REFERENCES Members(MemberID),
    ItemID INT NOT NULL FOREIGN KEY REFERENCES Items(ItemID),
    ReservationDate DATETIME NOT NULL,
    NotifiedDate DATETIME NULL
);
GO

--6. Trigger: Update reservation status
-- This trigger automatically updates the reservation status when an item is returned, notifying the member with the earliest reservation.
CREATE TRIGGER UpdateReservationStatus
ON Loans
AFTER UPDATE
AS
BEGIN
    IF EXISTS (SELECT * FROM inserted WHERE DateReturned IS NOT NULL)
    BEGIN
        DECLARE @ItemID INT;

        SELECT @ItemID = ItemID FROM inserted;

        UPDATE Reservations
        SET NotifiedDate = GETDATE()
        WHERE ReservationID = (
            SELECT TOP 1 ReservationID
            FROM Reservations
            WHERE ItemID = @ItemID AND NotifiedDate IS NULL
            ORDER BY ReservationDate ASC
        );
    END;
END;



-- Verify the backup
RESTORE VERIFYONLY 
FROM DISK = 'C:\Program Files\Microsoft SQL Server\MSSQL15.SQLEXPRESS\MSSQL\Backup\LibraryDB.bak';
GO

