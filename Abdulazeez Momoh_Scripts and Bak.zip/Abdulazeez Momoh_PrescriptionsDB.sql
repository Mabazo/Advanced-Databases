--QUESTION 1. The first stage of your task is to create a database and import the three tables from the csv file.

--1. First, create a new database called "PrescriptionsDB" 
CREATE DATABASE PrescriptionsDB;


--2. Switch to the newly created database:
USE PrescriptionsDB;
GO

--3.Create the Drugs table
CREATE TABLE Drugs (
    BNF_CODE NVARCHAR(20) PRIMARY KEY,
    CHEMICAL_SUBSTANCE_BNF_DESCR NVARCHAR(255),
	BNF_DESCRIPTION NVARCHAR(255),
	BNF_CHAPTER_PLUS_CODE NVARCHAR(255),   
);

--4. Create the Medical_Practice table
CREATE TABLE Medical_Practice (
    PRACTICE_CODE NVARCHAR(10) PRIMARY KEY,
    PRACTICE_NAME NVARCHAR(255),
    ADDRESS_1 NVARCHAR(255),
    ADDRESS_2 NVARCHAR(255),
    ADDRESS_3 NVARCHAR(255),
	ADDRESS_4 NVARCHAR(255),
    POSTCODE NVARCHAR(10)
);

--5. Create the Prescriptions table
CREATE TABLE Prescriptions (
    PRESCRIPTION_CODE NVARCHAR(255) PRIMARY KEY,
    PRACTICE_CODE NVARCHAR(10),
    BNF_CODE NVARCHAR(20),
    QUANTITY NVARCHAR(255),
    ITEMS FLOAT,
    ACTUAL_COST FLOAT,
    FOREIGN KEY (PRACTICE_CODE) REFERENCES Medical_Practice(PRACTICE_CODE),
    FOREIGN KEY (BNF_CODE) REFERENCES Drugs(BNF_CODE)
);
--The tables in the PrescriptionsDB database are linked through foreign key relationships. These relationships establish a connection between two tables by referencing a column in one table (the foreign key) to a primary key column in another table. This enforces data integrity by ensuring that the data in the foreign key column must have a corresponding value in the primary key column of the referenced table

--6.Import the data from the provided CSV files into the created tables using the SSMS.
--I imported the 3 Csv files(flat file) using the SSMS interface 
--I also selected the required datatypes

--7. Inserting  data into the Drugs table
INSERT INTO Drugs (PRACTICE_CODE, CHEMICAL_SUBSTANCE_BNF_DESCR, BNF_DESCRIPTION, BNF_CHAPTER_PLUS_CODE)
SELECT BNF_CODE, CHEMICAL_SUBSTANCE_BNF_DESCR, BNF_DESCRIPTION, BNF_CHAPTER_PLUS_CODE
FROM dbo.Drugs1;

--8. Inserting data into the Medical practice table
INSERT INTO Medical_Practice(PRACTICE_CODE, PRACTICE_NAME, ADDRESS_1, ADDRESS_2, ADDRESS_3, ADDRESS_4, POSTCODE)
SELECT PRACTICE_CODE, PRACTICE_NAME, ADDRESS_1, ADDRESS_2, ADDRESS_3, ADDRESS_4, POSTCODE
FROM dbo.Medical_Practice1;

--9. Inserting data into the Prescriptions table
INSERT INTO Prescriptions(PRESCRIPTION_CODE, PRACTICE_CODE, BNF_CODE, QUANTITY, ITEMS, ACTUAL_COST)
SELECT PRESCRIPTION_CODE, PRACTICE_CODE, BNF_CODE, QUANTITY, ITEMS, ACTUAL_COST
FROM dbo.Prescriptions1;


--QUESTION 2
-- Write a query that returns details of all drugs which are in the form of tablets or capsules. You can assume that all drugs in this form will have one of these words in the BNF_DESCRIPTION column.
SELECT *
FROM Drugs
WHERE BNF_DESCRIPTION LIKE '%tablet%' OR BNF_DESCRIPTION LIKE '%capsule%';
--This query searches for rows in the Drugs table where the BNF_DESCRIPTION contains either the word "tablet" or "capsule". The % symbol acts as a wildcard, allowing for any number of characters before or after the specified word.

--QUESTION 3
--Write a query that returns the total quantity for each of prescriptions � this is given by the number of items multiplied by the quantity. Some of the quantities are not integer values and your client has asked you to round the result to the nearest integer value.
--This is to calculate the total quantity for each prescription by multiplying the number of items by the quantity and rounding the result to the nearest integer value
SELECT PRESCRIPTION_CODE, ROUND(ITEMS * QUANTITY, 0) AS Total_Quantity
FROM Prescriptions;
--This query selects the PRESCRIPTION_CODE and calculates the Total_Quantity by multiplying ITEMS and QUANTITY for each row in the Prescriptions table. The ROUND function is used to round the result to the nearest integer value (0 decimal places).

--QUESTION 4
--Write a query that returns a list of the distinct chemical substances which appear in the Drugs table (the chemical substance is listed in the CHEMICAL_SUBSTANCE_BNF_DESCR column)
SELECT DISTINCT CHEMICAL_SUBSTANCE_BNF_DESCR
FROM Drugs
ORDER BY CHEMICAL_SUBSTANCE_BNF_DESCR;
--This query uses the DISTINCT keyword to select unique values of the CHEMICAL_SUBSTANCE_BNF_DESCR column from the Drugs table. The ORDER BY clause sorts the results in alphabetical order.

--QUESTION 5
--Write a query that returns the number of prescriptions for each BNF_CHAPTER_PLUS_CODE, along with the average cost for that chapter code, and the minimum and maximum prescription costs for that chapter code.
SELECT 
    D.BNF_CHAPTER_PLUS_CODE, 
    COUNT(P.PRESCRIPTION_CODE) AS NumberOfPrescriptions,
    AVG(P.ACTUAL_COST) AS AverageCost,
    MIN(P.ACTUAL_COST) AS MinCost,
    MAX(P.ACTUAL_COST) AS MaxCost
FROM 
    Prescriptions AS P
JOIN 
    Drugs AS D ON P.BNF_CODE = D.BNF_CODE
GROUP BY 
    D.BNF_CHAPTER_PLUS_CODE
ORDER BY 
    D.BNF_CHAPTER_PLUS_CODE;
--This query joins the Prescriptions table (P) with the Drugs table (D) on the BNF_CODE column. It then groups the results by the BNF_CHAPTER_PLUS_CODE column and calculates the count, average, minimum, and maximum cost for each group. The results are ordered by the BNF_CHAPTER_PLUS_CODE.

--QUESTION 6
--Write a query that returns the most expensive prescription prescribed by each practice, sorted in descending order by prescription cost (the ACTUAL_COST column in the prescription table.) Return only those rows where the most expensive prescription is more than �4000. You should include the practice name in your result.
WITH MostExpensivePrescriptions AS (
    SELECT 
        P.PRACTICE_CODE,
        MAX(P.ACTUAL_COST) AS MaxCost
    FROM 
        Prescriptions AS P
    GROUP BY 
        P.PRACTICE_CODE
    HAVING
        MAX(P.ACTUAL_COST) > 4000
)

SELECT
    M.PRACTICE_CODE,
    MP.PRACTICE_NAME,
    M.MaxCost
FROM
    MostExpensivePrescriptions AS M
JOIN
    Medical_Practice AS MP ON M.PRACTICE_CODE = MP.PRACTICE_CODE
ORDER BY
    M.MaxCost DESC;
--This query first creates a Common Table Expression (CTE) named MostExpensivePrescriptions that groups the Prescriptions table by the PRACTICE_CODE and calculates the maximum cost for each group, filtering only those with a maximum cost greater than �4000.
--Then, the main query selects the PRACTICE_CODE, PRACTICE_NAME, and the maximum cost from the CTE (MostExpensivePrescriptions) and the Medical_Practice table, joined on the PRACTICE_CODE column. The results are ordered by the maximum cost in descending order.

--QUESTION 7
--You should also write at least five queries of your own and provide a brief explanation of the results which each query returns. You should make use of all of the following atleast once:o Nested query including use of EXISTS or INo Joinso System functionso Use of GROUP BY, HAVING and ORDER BY clauses
--Query 1
--Find the total number of prescriptions for each medical practice, along with their practice name, sorted by the number of prescriptions in descending order.
SELECT 
    MP.PRACTICE_NAME,
    COUNT(P.PRESCRIPTION_CODE) AS TotalPrescriptions
FROM 
    Medical_Practice AS MP
JOIN 
    Prescriptions AS P ON MP.PRACTICE_CODE = P.PRACTICE_CODE
GROUP BY 
    MP.PRACTICE_NAME
ORDER BY 
    TotalPrescriptions DESC;
--This query retrieves the total number of prescriptions issued by each medical practice and displays the results in descending order based on the total number of prescriptions.
--The result will be a list of medical practices along with the total number of prescriptions they have issued, sorted in descending order by the number of prescriptions.

--Query 2
--Find the top 5 drugs with the highest average cost per prescription.
SELECT 
    TOP 5 D.BNF_DESCRIPTION,
    AVG(P.ACTUAL_COST) AS AvgCost
FROM 
    Drugs AS D
JOIN 
    Prescriptions AS P ON D.BNF_CODE = P.BNF_CODE
GROUP BY 
    D.BNF_DESCRIPTION
ORDER BY 
    AvgCost DESC;
--The result of this query will be a list of the top 5 drugs with the highest average prescription cost, sorted in descending order by the average cost of each drug.

--Query 3
--Find the total cost of prescriptions for each BNF_CHAPTER_PLUS_CODE, only including chapters with a total cost greater than �10,000.
SELECT 
    D.BNF_CHAPTER_PLUS_CODE,
    SUM(P.ACTUAL_COST) AS TotalCost
FROM 
    Drugs AS D
JOIN 
    Prescriptions AS P ON D.BNF_CODE = P.BNF_CODE
GROUP BY 
    D.BNF_CHAPTER_PLUS_CODE
HAVING 
    SUM(P.ACTUAL_COST) > 10000
ORDER BY 
    TotalCost DESC;
--The result of this query will be a list of BNF chapter codes and their total cost where the total cost of prescriptions under each chapter code is greater than 10,000, sorted in descending order by the total cost.

--Query 4
--Find the medical practices that have never prescribed any drugs in the '05: Infections' BNF chapter.
SELECT 
    MP.*
FROM 
    Medical_Practice AS MP
WHERE 
    NOT EXISTS (
        SELECT 1
        FROM 
            Prescriptions AS P
        JOIN 
            Drugs AS D ON P.BNF_CODE = D.BNF_CODE
        WHERE 
            MP.PRACTICE_CODE = P.PRACTICE_CODE AND D.BNF_CHAPTER_PLUS_CODE = '05: Infections'
    );
--The result of this query will be a list of all medical practice details that have not prescribed any medication in the BNF chapter code '05: Infections'.

--Query 5
--Find the total items and total cost for each drug, where the total cost is greater than �5000, sorted by total cost in descending order.
SELECT 
    D.BNF_DESCRIPTION,
    SUM(P.ITEMS) AS TotalItems,
    SUM(P.ACTUAL_COST) AS TotalCost
FROM 
    Drugs AS D
JOIN 
    Prescriptions AS P ON D.BNF_CODE = P.BNF_CODE
GROUP BY 
    D.BNF_DESCRIPTION
HAVING 
    SUM(P.ACTUAL_COST) > 5000
ORDER BY 
    TotalCost DESC;
--The result of this query will be a list of BNF descriptions, total items prescribed, and the total cost of the drugs with a total cost greater than 5000, ordered by the total cost in descending order

--Query 6
--Find the top 5 most prescribed drugs by total items for each medical practice.
WITH PracticeDrugs AS (
    SELECT
        MP.PRACTICE_NAME,
        D.CHEMICAL_SUBSTANCE_BNF_DESCR,
        SUM(P.ITEMS) AS TotalItems
    FROM
        Medical_Practice AS MP
    JOIN
        Prescriptions AS P ON MP.PRACTICE_CODE = P.PRACTICE_CODE
    JOIN
        Drugs AS D ON P.BNF_CODE = D.BNF_CODE
    GROUP BY
        MP.PRACTICE_NAME, D.CHEMICAL_SUBSTANCE_BNF_DESCR
),
Ranking AS (
    SELECT
        PD.PRACTICE_NAME,
        PD.CHEMICAL_SUBSTANCE_BNF_DESCR,
        PD.TotalItems,
        ROW_NUMBER() OVER (PARTITION BY PD.PRACTICE_NAME ORDER BY PD.TotalItems DESC) AS Rank
    FROM
        PracticeDrugs AS PD
)
SELECT
    R.PRACTICE_NAME,
    R.CHEMICAL_SUBSTANCE_BNF_DESCR,
    R.TotalItems,
    R.Rank
FROM
    Ranking AS R
WHERE
    R.Rank <= 5;
--The result of this query returns the top 5 most prescribed drugs by total items for each medical practice. A common table expression (CTE) is used to group the total items by medical practice and drug. The ROW_NUMBER() function is used to rank the drugs for each medical practice by total items in descending order. The final result is filtered to show only the top 5 drugs for each medical practice.

--Query 7
--Find the total cost and average cost per item for each BNF chapter code.
SELECT
    D.BNF_CHAPTER_PLUS_CODE,
    SUM(P.ACTUAL_COST) AS TotalCost,
    AVG(P.ACTUAL_COST / P.ITEMS) AS AvgCostPerItem
FROM
    Drugs AS D
JOIN
    Prescriptions AS P ON D.BNF_CODE = P.BNF_CODE
GROUP BY
    D.BNF_CHAPTER_PLUS_CODE;
-- The result of this query returns the total cost and average cost per item for each BNF chapter code. The query joins the Drugs and Prescriptions tables and groups the results by BNF chapter code. The total cost is calculated by summing the actual cost of the prescriptions, and the average cost per item is calculated by dividing the actual cost by the number of items and taking the average.

--Query 8
--Find the medical practices that have never prescribed a specific drug
SELECT
    MP.PRACTICE_NAME
FROM
    Medical_Practice AS MP
WHERE NOT EXISTS (
    SELECT 1
    FROM
        Prescriptions AS P
    JOIN
        Drugs AS D ON P.BNF_CODE = D.BNF_CODE
    WHERE
        MP.PRACTICE_CODE = P.PRACTICE_CODE
        AND D.CHEMICAL_SUBSTANCE_BNF_DESCR = 'Amoxicillin'
);
--The result of this query returns the medical practices that have never prescribed a specific drug (e.g., Amoxicillin). The query uses a subquery with the NOT EXISTS clause to check for the absence of a prescription for the specified drug in each medical practice. The subquery joins the Prescriptions and Drugs tables and filters the results based on the practice code and the specified drug's chemical substance description.



-- Verify the backup
RESTORE VERIFYONLY 
FROM DISK = 'C:\Program Files\Microsoft SQL Server\MSSQL15.SQLEXPRESS\MSSQL\Backup\PrescriptionsDB.bak';
GO